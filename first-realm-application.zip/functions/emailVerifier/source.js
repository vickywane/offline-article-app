 exports = ({ token, tokenId, username, }) => {
  const sgMail = require('@sendgrid/mail');
  
sgMail.setApiKey(context.values.get("SENDGRID_API_KEY"));

const msg = {
  to : username,
  from: context.values.get("SENGRID_EMAIL"),
  subject: 'Welcome to Demo Offline App',
  text: 'Do all things offline with your app powered by Realm!',
  html: `<html> 
              <h1> Welcome to Offline Realm App </h1>  <p> Your verification code is <b> ${token} </b> and the code id is <b> ${tokenId} </b>. </p>
              <br /> <p> Use the two codes above to access your new account. </p>
         </html>`,
};

sgMail
  .send(msg)
  .then(() => {return {status : "success" }}, error => {
        console.error(error)
        return {
           status  : "pending"
        }
  });
};



