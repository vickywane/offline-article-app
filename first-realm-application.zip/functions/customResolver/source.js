

exports = (input) => {
  return { "hello": input };
};
