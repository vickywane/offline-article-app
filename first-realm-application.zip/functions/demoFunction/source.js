exports = function(changeEvent) {
   if(changeEvent.operationType !== "INSERT") { return }
   
  // Format a message with the inserted document's `title` field.
  const { firstname } = changeEvent.fullDocument;

  console.log(`A new user was inserted with the name : ${firstname}`)
};
