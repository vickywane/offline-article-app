
exports = ({  email , code }) => {
  const accountSid = context.values.get("TWILIO_SID")
  const authToken =  context.values.get("TWILIO_AUTH_TOKEN")

  const client = require('twilio')(accountSid, authToken);
  
   client.verify.services(context.values.get("TWILIO_EMAIL_SID"))
   .verificationChecks
   .create({to : email , code})
   .then(check => {
      console.log(check, "data response")
     
     return check.status
     
   }).catch(e => { return "unapproved"  })
};

